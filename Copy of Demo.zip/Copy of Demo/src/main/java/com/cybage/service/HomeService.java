package com.cybage.service;

import java.util.List;

import com.cybage.model.Role;


public interface HomeService {
	
	
	String registerRole(Role role);
	 List<Role> getRole();
	
}
