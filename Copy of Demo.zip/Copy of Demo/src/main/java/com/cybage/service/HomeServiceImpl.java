package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.dao.HomeDao;
import com.cybage.model.Role;
import com.cybage.model.User;

@Service
public class HomeServiceImpl implements HomeService {

	@Autowired
	private HomeDao dao;
	
	public HomeServiceImpl() {
		System.out.println("HomeServiceImpl Ctor");
	}
	
	

	

	@Override
	public String registerRole(Role role) {
		return dao.registerRole(role);
	}
	
	@Override
	public List<Role> getRole() {
		
		return dao.getRole();
	}

}
