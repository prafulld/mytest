package com.cybage.dao;

import java.util.List;

import com.cybage.model.Role;
import com.cybage.model.User;

public interface HomeDao {
	
	
	String registerRole(Role role);
	List<Role> getRole();
	
}
