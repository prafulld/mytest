package com.cybage.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.model.Role;
import com.cybage.model.User;

@Repository
@Transactional
public class HomeDaoImpl implements HomeDao {

	@Autowired
	private SessionFactory factory;
	
	public HomeDaoImpl() {
		System.out.println("HomeDaoImpl Ctor");
	}
	
	

	@Override
	public String registerRole(Role role) {
		String id =  (String) factory.getCurrentSession().save(role);
		
		System.out.println(id);
		
		if(id == null)
			return "fail";
		return "success";
	}



	@SuppressWarnings("unchecked")
	@Override
	public List<Role> getRole() {
		// TODO Auto-generated method stub
		//return  factory.getCurrentSession().createQuery("select d from Role d").list();
		return factory.getCurrentSession().createQuery("from Role").list();
		
		
	}
	
		
	
	

}
