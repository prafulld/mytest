package com.cybage.model;

import java.util.UUID;

public class Util 
{
	public static String getUUID()
	{
		return UUID.randomUUID().toString();
	}
}
