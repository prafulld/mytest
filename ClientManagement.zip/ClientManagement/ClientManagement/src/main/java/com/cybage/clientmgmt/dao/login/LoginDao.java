package com.cybage.clientmgmt.dao.login;

import com.cybage.clientmgmt.models.login.User;

public interface LoginDao {
	User findByUserName(String username);
}
