package com.cybage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.cybage.model.Client;
import com.cybage.model.Domain;
import com.cybage.model.User;
import com.cybage.service.HomeService;

@RestController
@RequestMapping("/home")
public class HomeController {
	
	@Autowired
	HomeService service;
	
	String lastid;
	
	public HomeController() {
		System.out.println("Home Controller Ctor");
	}
	
	
	
	@RequestMapping(value = "/registerclient", method = RequestMethod.POST)
    public ResponseEntity<String> createUser(@RequestBody Client client,    UriComponentsBuilder ucBuilder) {
        System.out.println("*******"+client);
 
        
      lastid= service.registerClient(client);
       System.out.println(lastid);
        HttpHeaders headers = new HttpHeaders();
        
        return new ResponseEntity<String>(headers, HttpStatus.CREATED);
    }
	
	@RequestMapping(value = "/getdomain", method = RequestMethod.GET)
    public ResponseEntity<List<Domain>> listAllDomain() {
        List<Domain> domain = service.getDomain();
        if(domain.isEmpty()){
            return new ResponseEntity<List<Domain>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
        }
        return new ResponseEntity<List<Domain>>(domain, HttpStatus.OK);
    }
	
	@RequestMapping(value = "/getclients", method = RequestMethod.GET)
    public ResponseEntity<List<Client>> listAllClients() {
        List<Client> client = service.getClients();
        if(client.isEmpty()){
            return new ResponseEntity<List<Client>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
        }
        return new ResponseEntity<List<Client>>(client, HttpStatus.OK);
    }
	
	@SuppressWarnings("unused")
	@RequestMapping(value = "/getlastclientid", method = RequestMethod.GET)
    public ResponseEntity<String> getlastclientid() {
		 
		
		String lastid1 = "\""+lastid+"\"";
		//String lastid1 = "{id:"+ lastid +"}";
        if(lastid1==null){
            return new ResponseEntity<String>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
        }
        return new ResponseEntity<String>(lastid1, HttpStatus.OK);
    }
	
	 @RequestMapping(value = "/deleteclient/{id}", method = RequestMethod.DELETE)
	    public ResponseEntity<Client> deleteClient(@PathVariable("id") String id) {
	        System.out.println("Fetching & Deleting User with id " + id);
	 
	        /*Client user = userService.findById(id);
	        if (user == null) {
	            System.out.println("Unable to delete. User with id " + id + " not found");
	            return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
	        }*/
	 
	        service.deleteClientById(id);
	        return new ResponseEntity<Client>(HttpStatus.NO_CONTENT);
	    }
	
	 
	 @RequestMapping(value = "/registeruser", method = RequestMethod.POST)
	    public ResponseEntity<String> registerUser(@RequestBody User user,    UriComponentsBuilder ucBuilder) {
	        System.out.println("*******"+user);
	 
	        
	      lastid= service.registerUser(user);
	       System.out.println(lastid);
	        HttpHeaders headers = new HttpHeaders();
	        
	        return new ResponseEntity<String>(headers, HttpStatus.CREATED);
	    }
	 
	 @RequestMapping(value = "/getusers", method = RequestMethod.GET)
	    public ResponseEntity<List<User>> listAllUsers() {
	        List<User> user = service.getUsers();
	        if(user.isEmpty()){
	            return new ResponseEntity<List<User>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
	        }
	        return new ResponseEntity<List<User>>(user, HttpStatus.OK);
	    }
	 
	 @RequestMapping(value = "/deleteuser/{id}", method = RequestMethod.DELETE)
	    public ResponseEntity<User> deleteUser(@PathVariable("id") String id) {
	        System.out.println("Fetching & Deleting User with id " + id);
	 
	        /*Client user = userService.findById(id);
	        if (user == null) {
	            System.out.println("Unable to delete. User with id " + id + " not found");
	            return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
	        }*/
	 
	        service.deleteUserById(id);
	        return new ResponseEntity<User>(HttpStatus.NO_CONTENT);
	    }
	/*@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String showRegisterForm(@ModelAttribute("user") User user)
	{
		System.out.println("IN showRegisterForm");
		return "register";
	}
	
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String processRegisterForm(@ModelAttribute User user, ModelMap model)
	{
		
		String status = service.registerUser(user);
		model.addAttribute("status", status);
		return "home";
	}
	
	@RequestMapping(value = "/get", method = RequestMethod.GET)
	public String getUser(ModelMap model)
	{
		model.addAttribute("ad", service.getUser(8));
		return "home";
	}
	
	
	@RequestMapping(value="/registerclient",method=RequestMethod.GET)
	public String registerClient(@ModelAttribute("client") Client client)
	{
		System.out.println("IN showRegisterclientForm");
		return "registerclient";
	}
	
	@RequestMapping(value="/registerclient",method=RequestMethod.POST)
	public String processRegisterClient(@ModelAttribute Client client,ModelMap map)
	{
		System.out.println("in process resgister client");
		String status=service.registerClient(client);
		System.out.println(status);
		map.addAttribute("status1",status);
		return "home1";
	}
	
	

	@RequestMapping(value="/registeruser",method=RequestMethod.GET)
	public String registerUsers(@ModelAttribute("users") Users users)
	{
		System.out.println("IN showRegisteruserForm");
		return "registeruser";
	}
	
	@RequestMapping(value="/registeruser",method=RequestMethod.POST)
	public String processregisterusers(@ModelAttribute Users users,ModelMap map)
	{
		System.out.println("IN processRegisteruserForm");
		
		String status= service.registerUsers(users);
		
		map.addAttribute("status2",status);
		return "welcomeusers";
		
		
	}*/
	
}
